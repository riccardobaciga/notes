export default function removeUserFromSession(){
    localStorage.removeItem('userNotesRecord');
}