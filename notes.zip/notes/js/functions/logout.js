import showLogin from "../pages/login.js";
export default function logout(){

    showLogin();
}